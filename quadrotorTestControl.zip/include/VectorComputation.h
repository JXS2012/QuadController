#include <pcl/point_cloud.h>
#include <pcl/kdtree/kdtree_flann.h>

pcl::PointXYZ normalize(pcl::PointXYZ); //calculate unit vector in the same direction as given vector
pcl::PointXYZ crossProduct(pcl::PointXYZ , pcl::PointXYZ );
pcl::PointXYZ scalarProduct(double , pcl::PointXYZ );
pcl::PointXYZ vectorMinus(pcl::PointXYZ , pcl::PointXYZ );
pcl::PointXYZ vectorPlus(pcl::PointXYZ , pcl::PointXYZ );
double norm(pcl::PointXYZ); //calculate norm of vector
double dotProduct(pcl::PointXYZ, pcl::PointXYZ);
